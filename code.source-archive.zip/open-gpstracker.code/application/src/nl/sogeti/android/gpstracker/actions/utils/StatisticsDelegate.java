package nl.sogeti.android.gpstracker.actions.utils;

public interface StatisticsDelegate
{
   void finishedCalculations(StatisticsCalulator calculated);
}